#ifndef __CRC_H
#define __CRC_H

#include "sys.h"

u32 CRC_Compute(u8 *pushMsg,u8 usDataLen);

#endif

